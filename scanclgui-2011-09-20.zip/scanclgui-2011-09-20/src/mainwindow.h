#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QProcess>
#include <QTextCursor>

namespace Ui {
class MainWindow;
}

class CheckableProxyModel;


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();


private slots:
    void selectedItemsChanged();
    void on_btnScan_clicked();
    void on_btnDisplayVersion_clicked();
    void on_btnClearOutput_clicked();
    void on_btnExit_clicked();
    void on_btnStop_clicked();

    void updateOutputError();
    void updateOutputText();
    void updateOutputExit();

private:
    void updateCursorPosition();
    void startScanclProcess();
    void killScanclProcess();
    void getUserSelectedOptions();
    bool checkScanclExists();

    Ui::MainWindow *ui;
    CheckableProxyModel* m_checkProxy;
    QProcess *proc;
    QStringList argList;
    QTextCursor cursor;
    bool bProcStarted;

};

#endif // MAINWINDOW_H
