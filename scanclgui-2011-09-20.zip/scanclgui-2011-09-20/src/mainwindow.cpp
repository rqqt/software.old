#define VERSION "Simple Avira Scancl GUI ("__DATE__")"

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "checkableproxymodel.h"
#include <QFileSystemModel>
#include <QHeaderView>
#include <QtGui>
#include <QFile>
#include <QProcess>
#include <QTextCursor>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle(VERSION);

    QFileSystemModel* fsModel = new QFileSystemModel(this);
    fsModel->setRootPath("c:/"); //otherwise the model does not populate

    m_checkProxy = new CheckableProxyModel(this);
    m_checkProxy->setSourceModel(fsModel);
    ui->filteredTreeView->setModel(m_checkProxy);
    ui->filteredTreeView->sortByColumn(0, Qt::AscendingOrder);
    ui->filteredTreeView->setColumnWidth(0, 250);

    connect(m_checkProxy, SIGNAL(checkedNodesChanged()), this, SLOT(selectedItemsChanged()));

    cursor =  ui->txtOutput->textCursor();
}

MainWindow::~MainWindow()
{
    delete ui;
}

bool MainWindow::checkScanclExists()
{

    QFile fWin( "scancl.exe" );
    QFile fLin ("scancl");

    if ( fWin.exists() || fLin.exists() ) 
        return true;
    else
        return false;
    
}

void MainWindow::startScanclProcess()
{
    if (checkScanclExists()) {
        ui->btnScan->setEnabled(false);
        ui->btnDisplayVersion->setEnabled(false);
        ui->txtOutput->appendPlainText("Starting scancl.exe...");
        ui->txtOutput->appendPlainText("\n");

        bProcStarted = true;

        proc = new QProcess();

        connect(proc, SIGNAL(readyReadStandardError()), this, SLOT(updateOutputError()));
        connect(proc, SIGNAL(readyReadStandardOutput()), this, SLOT(updateOutputText()));
        connect(proc, SIGNAL(finished(int)), this, SLOT(updateOutputExit()));

#ifdef Q_WS_X11
        proc->start("./scancl",argList);
#endif

#ifdef Q_WS_WIN
        proc->start("scancl.exe",argList);
#endif

    } else 

        ui->txtOutput->appendPlainText("scancl.exe not found!");
}

void MainWindow::killScanclProcess()
{
    if (bProcStarted) {
        if (proc->state() == QProcess::Running) 
            proc->kill();
        
        bProcStarted=false;
    }
}

void MainWindow::updateCursorPosition()
{
    cursor.movePosition(QTextCursor::End);
    ui->txtOutput->setTextCursor(cursor);
}

void MainWindow::updateOutputText()
{
    QString data = proc->readAllStandardOutput();
    ui->txtOutput->appendPlainText(data);
    updateCursorPosition();
}

void MainWindow::updateOutputError()
{
    QString data = proc->readAllStandardError();
    ui->txtOutput->appendPlainText(data);
    ui->btnScan->setEnabled(true);
    ui->btnDisplayVersion->setEnabled(true);
}

void MainWindow::updateOutputExit()
{
    ui->btnScan->setEnabled(true);
    ui->btnDisplayVersion->setEnabled(true);

    if (proc->exitCode()== 0) {
        ui->txtOutput->appendPlainText("Done.");
        updateCursorPosition();
    } else 
        ui->txtOutput->appendPlainText("Error!");
    
    ui->txtOutput->appendPlainText("\n");
}

void MainWindow::selectedItemsChanged()
{
    argList.clear();

    QModelIndexList selectedFiles;
    QModelIndexList selectedDirectories;

    m_checkProxy->checkedState().checkedLeafSourceModelIndexes(selectedFiles).checkedBranchSourceModelIndexes(selectedDirectories);

    foreach (const QModelIndex index, selectedFiles) {
        argList += index.data(QFileSystemModel::FilePathRole).toString();
    }

    foreach (const QModelIndex index, selectedDirectories) {
        argList += index.data(QFileSystemModel::FilePathRole).toString();
    }
}

void MainWindow::getUserSelectedOptions()
{
    if (ui->radiobtnScanAllFiles->isChecked()) {argList << "--allfiles";}
    if (ui->radiobtnScanUseSmartExtensions->isChecked()) {argList << "--smartextensions";}
    if (ui->radiobtnScanUseVDFExtensions->isChecked()) { argList << "--extensionlist";}
    if (ui->chkScanAllBootSectors->isChecked()) {argList << "--allboot";}
    if (ui->chkDetectAllMalwareTypes->isChecked()) {argList << "--withtype=all";}
    if (ui->chkScanArchives->isChecked()) {argList << "--scaninarchive";}
    if (ui->chkDefaultActionClean->isChecked()) {argList << "--defaultaction=clean";}
    if (ui->chkDefaultActionQuarantine->isChecked()) {argList << "--defaultaction=move";}
    if (ui->chkDefaultActionRename->isChecked()) {argList << "--defaultaction=rename";}
    if (ui->chkDefaultActionDelete->isChecked()) {argList << "--defaultaction=delete";}
    if (ui->chkDefaultActiionDeleteArchive->isChecked()) {argList << "--defaultaction=delete-archive";}
    if (ui->chkDefaultActionIgnore->isChecked()) {argList << "--defaultaction=ignore";}
    if (ui->chkSuspActionClean->isChecked()) {argList << "--suspiciousaction=clean";}
    if (ui->chkSuspActionQuarantine->isChecked()) { argList << "--suspiciousaction=move";}
    if (ui->chkSuspActionRename->isChecked()) {argList << "--suspiciousaction=rename";}
    if (ui->chkSuspActionDelete->isChecked()) {argList << "--suspiciousaction=delete";}
    if (ui->chkSuspActiionDeleteArchive->isChecked()) { argList << "--suspiciousaction=delete-archive";}
    if (ui->chkSuspActionIgnore->isChecked()) {argList << "--suspiciousaction=ignore";}
    if (ui->chkDontScanGames->isChecked()) {argList << "--withouttype=game";}
    if (ui->chkScanInQuietMode->isChecked()) {argList << "--quiet";}
    argList << "--heurlevel=" + QString("%1").arg(ui->spinboxHeur->value());
    argList << "--renameext=VIR";
}

void MainWindow::on_btnScan_clicked()
{
    getUserSelectedOptions();
    startScanclProcess();
    selectedItemsChanged();
}

void MainWindow::on_btnDisplayVersion_clicked()
{
    argList.clear();
    argList <<"--version";
    startScanclProcess();
}

void MainWindow::on_btnClearOutput_clicked()
{
    ui->txtOutput->clear();
}

void MainWindow::on_btnExit_clicked()
{
    killScanclProcess();
    QCoreApplication::quit();
}

void MainWindow::on_btnStop_clicked()
{
    killScanclProcess();
}
