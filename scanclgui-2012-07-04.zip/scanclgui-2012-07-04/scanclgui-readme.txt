Simple Avira ScanCL GUI 
2012-07-04
sourceforge.net/projects/avirascanclgui

Simple Avira ScanCL GUI provides a GUI for Avira ScanCL. 

AntiVir VDF update package, HBEDV.KEY and scancl.exe must be in the same folder as scanclgui.exe. 

Download Avira Command Line Scanner ScanCL here:
https://www.avira.com/en/support-download-avira-antivir-command-line-scanner-scancl

Download AntiVir VDF update package here:
http://dl.antivir.de/down/vdf/ivdf_fusebundle_nt_en.zip