#define VERSION "Simple Avira Scancl GUI ("__DATE__")"

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "checkableproxymodel.h"
#include <QFileSystemModel>
#include <QHeaderView>
#include <QtGui>
#include <QFile>
#include <QProcess>
#include <QTextCursor>

MainWindow::MainWindow(QWidget *parent) :
		QMainWindow(parent), ui(new Ui::MainWindow)
{
	ui->setupUi(this);
	setWindowTitle(VERSION);

	QFileSystemModel* fsModel = new QFileSystemModel(this);

#ifdef Q_WS_X11
	fsModel->setRootPath("/");
#endif

#ifdef Q_WS_WIN
	fsModel->setRootPath("c:/"); //otherwise the model does not populate
#endif

	m_checkProxy = new CheckableProxyModel(this);
	m_checkProxy->setSourceModel(fsModel);
	ui->filteredTreeView->setModel(m_checkProxy);
	ui->filteredTreeView->sortByColumn(0, Qt::AscendingOrder);
	ui->filteredTreeView->setColumnWidth(0, 250);

	connect(m_checkProxy, SIGNAL(checkedNodesChanged()), this, SLOT(getSelectedFiles()));

	cursor = ui->txtOutput->textCursor();

	bProcStarted = false; //quick fix for windows xp x86 crashes

}

MainWindow::~MainWindow()
{
	delete ui;
}

bool MainWindow::checkScanclExists()
{

	QFile fWin("scancl.exe");
	QFile fLinux("scancl");

	if (fWin.exists() || fLinux.exists())
		return true;
	else
		return false;

}

void MainWindow::startScanclProcess()
{
	if (checkScanclExists())
	{

		bProcStarted = true; //quick fix for windows xp x86 crashes

		ui->btnScan->setEnabled(false);
		ui->btnDisplayVersion->setEnabled(false);
		ui->txtOutput->appendPlainText("Starting scancl.exe...");
		ui->txtOutput->appendPlainText("\n");

		proc = new QProcess();

		connect(proc, SIGNAL(readyReadStandardError()), this, SLOT(updateOutputError()));
		connect(proc, SIGNAL(readyReadStandardOutput()), this, SLOT(updateOutputText()));
		connect(proc, SIGNAL(finished(int)), this, SLOT(updateOutputExit()));

#ifdef Q_WS_X11
		proc->start("./scancl", arg);
#endif

#ifdef Q_WS_WIN
		proc->start("scancl.exe",arg);
#endif

	}
	else

		ui->txtOutput->appendPlainText("scancl.exe not found!");

}

void MainWindow::killScanclProcess()
{
	if (proc->state() == QProcess::Running)
	{
		ui->txtOutput->appendPlainText("Killing scancl.exe...");
		proc->kill();
	}
}

void MainWindow::updateCursorPosition()
{
	cursor.movePosition(QTextCursor::End);

	ui->txtOutput->setTextCursor(cursor);
}

void MainWindow::updateOutputText()
{
	QString data = proc->readAllStandardOutput();
	ui->txtOutput->appendPlainText(data);
	updateCursorPosition();
}

void MainWindow::updateOutputError()
{
	QString data = proc->readAllStandardError();

	ui->txtOutput->appendPlainText(data);
	ui->btnScan->setEnabled(true);
	ui->btnDisplayVersion->setEnabled(true);

	updateCursorPosition();
}

void MainWindow::updateOutputExit()
{
	ui->btnScan->setEnabled(true);
	ui->btnDisplayVersion->setEnabled(true);

	if (proc->exitStatus() == QProcess::NormalExit)
		ui->txtOutput->appendPlainText("Finished without errors.");

	if (!proc->exitStatus() == QProcess::NormalExit)
		ui->txtOutput->appendPlainText("Finished with errors.");

	updateCursorPosition();
}

void MainWindow::getSelectedFiles()
{
	QModelIndexList selectedFiles;
	QModelIndexList selectedDirectories;

	m_checkProxy->checkedState().checkedLeafSourceModelIndexes(selectedFiles).checkedBranchSourceModelIndexes(selectedDirectories);

	foreach (const QModelIndex index, selectedFiles)
	{
		arg += index.data(QFileSystemModel::FilePathRole).toString();
	}

	foreach (const QModelIndex index, selectedDirectories)
	{
		arg += index.data(QFileSystemModel::FilePathRole).toString();
	}
}

void MainWindow::getSelectedOptions()
{
	arg << "--renameext=VIR";
	arg << "--heurlevel=" + QString("%1").arg(ui->spinboxHeur->value());

	if (ui->chkDontScanGames->isChecked()) {arg << "--withouttype=game";}
	if (ui->chkScanInQuietMode->isChecked()) {arg << "--quiet";}

	if (ui->radiobtnScanAllFiles->isChecked()) {arg << "--allfiles";}
	if (ui->radiobtnScanUseSmartExtensions->isChecked()) {arg << "--smartextensions";}
	if (ui->radiobtnScanUseVDFExtensions->isChecked()) {arg << "--extensionlist";}
	if (ui->chkScanAllBootSectors->isChecked()) {arg << "--allboot";}
	if (ui->chkDetectAllMalwareTypes->isChecked()) {arg << "--withtype=all";}
	if (ui->chkScanArchives->isChecked()) {arg << "--scaninarchive";}

	if (ui->chkDefaultActionClean->isChecked()) {arg << "--defaultaction=clean";}
	if (ui->chkDefaultActionQuarantine->isChecked()) {arg << "--defaultaction=move";}
	if (ui->chkDefaultActionRename->isChecked()) {arg << "--defaultaction=rename";}
	if (ui->chkDefaultActionDelete->isChecked()) {arg << "--defaultaction=delete";}
	if (ui->chkDefaultActiionDeleteArchive->isChecked()) {arg << "--defaultaction=delete-archive";}
	if (ui->chkDefaultActionIgnore->isChecked()) {arg << "--defaultaction=ignore";}

	if (ui->chkSuspActionClean->isChecked()) {arg << "--suspiciousaction=clean";}
	if (ui->chkSuspActionQuarantine->isChecked()) {arg << "--suspiciousaction=move";}
	if (ui->chkSuspActionRename->isChecked()) {arg << "--suspiciousaction=rename";}
	if (ui->chkSuspActionDelete->isChecked()) {arg << "--suspiciousaction=delete";}
	if (ui->chkSuspActiionDeleteArchive->isChecked()) {arg << "--suspiciousaction=delete-archive";}
	if (ui->chkSuspActionIgnore->isChecked()) {arg << "--suspiciousaction=ignore";}
}

void MainWindow::on_btnScan_clicked()
{
	arg.clear();
	getSelectedFiles();
	getSelectedOptions();
	startScanclProcess();
	arg.clear();
}

void MainWindow::on_btnDisplayVersion_clicked()
{
	arg.clear();
	arg << "--version";
	startScanclProcess();
	arg.clear();
}

void MainWindow::on_btnClearOutput_clicked()
{
	ui->txtOutput->clear();
}

void MainWindow::on_btnExit_clicked()
{
	if (bProcStarted) //quick fix for windows xp x86 crashes
		killScanclProcess();

	QCoreApplication::exit(0);

}

void MainWindow::on_btnStop_clicked()
{
	if (bProcStarted) //quick fix for windows xp x86 crashes
		killScanclProcess();
}
